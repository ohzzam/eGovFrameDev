# Shell Name : moveDrctry.sh                                              
# Description : 파일을 이동한다.    
# Modification Information                                                              
#                                                                    
# 수정일                      수정자                   수정내용
# -------      --------     ---------------------------
# 2009.02.11    박지욱                   최초 생성
#
# @author 공통 서비스 개발팀 박지욱
# @since 2009. 02. 11
# @version 1.0
# @see
#
# Copyright (C) 2009 by MOPAS  All right reserved.
mv $1 $2